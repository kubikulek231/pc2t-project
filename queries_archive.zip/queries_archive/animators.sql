create table animators (
	id integer primary key,
	act_name varchar(64),
	act_surname varchar(64),
	act_birthdate DATE NULL
)